package org.nixybuilder.terrartp;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.List;
import java.util.Random;

public class Terrartp extends JavaPlugin implements CommandExecutor {
    private FileConfiguration config;
    private final Random random = new Random();
    @Override
    public void onEnable() {
        saveDefaultConfig();
        config = getConfig();
        getCommand("rtp").setExecutor(this);
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(getMessage("not-a-player"));
            return true;
        }
        Player player = (Player) sender;
        World world = player.getWorld();
        List<String> disabledWorlds = config.getStringList("rtp.disabled-worlds");
        if (disabledWorlds.contains(world.getName())) {
            String defaultWorldName = config.getString("rtp.default-world", "world");
            world = Bukkit.getWorld(defaultWorldName);
            if (world == null) {
                player.sendMessage(getMessage("world-not-found"));
                return true;
            }
        }
        teleportRandomlyAsync(player, world);
        return true;
    }
    private void teleportRandomlyAsync(Player player, World world) {
        int minRadius = config.getInt("rtp.worlds." + world.getName() + ".min-radius", 100);
        int maxRadius = config.getInt("rtp.worlds." + world.getName() + ".max-radius", 5000);
        int airCheckRadius = config.getInt("rtp.worlds." + world.getName() + ".air-check-radius", 50);
        List<String> allowedBlocks = config.getStringList("rtp.worlds." + world.getName() + ".allowed-blocks");
        new BukkitRunnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    Location randomLocation = getRandomLocation(world, minRadius, maxRadius);
                    if (randomLocation == null) continue;
                    randomLocation.getChunk().load(true);
                    Material blockType = randomLocation.getBlock().getType();
                    if (!allowedBlocks.contains(blockType.name())) continue;
                    if (!hasEnoughAirAbove(randomLocation, airCheckRadius)) continue;
                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            player.teleport(randomLocation.add(0.5, 1, 0.5));
                            player.sendMessage(getMessage("teleport-success"));
                        }
                    }.runTask(Terrartp.this);
                    return;
                }
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        player.sendMessage(getMessage("teleport-fail"));
                    }
                }.runTask(Terrartp.this);
            }
        }.runTaskAsynchronously(this);
    }
    private Location getRandomLocation(World world, int minRadius, int maxRadius) {
        int x = random.nextInt(maxRadius - minRadius) + minRadius;
        int z = random.nextInt(maxRadius - minRadius) + minRadius;
        int highestY = world.getHighestBlockYAt(x, z);
        return new Location(world, x, highestY, z);
    }
    private boolean hasEnoughAirAbove(Location location, int airCheckRadius) {
        for (int i = 1; i <= airCheckRadius; i++) {
            if (!location.clone().add(0, i, 0).getBlock().isEmpty()) {
                return false;
            }
        }
        return true;
    }
    private String getMessage(String key) {
        String message = config.getString("messages." + key, "&cMessage not found: " + key);
        return ChatColor.translateAlternateColorCodes('&', message);
    }
}